package controller.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;
import model.ProductAdd;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/")
//@WebServlet(asyncSupported = true, urlPatterns = { "/ProductServlet" })
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//making a global object of database controller
	//DatabaseController dbController = new DatabaseController();
	
	private DatabaseController dbController;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        this.dbController = new DatabaseController();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

    
    //doGet() method for data insertion and updating
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		
            switch (action) {
                case "/new":
                	productAddForm(request, response);
                    break;
                case "/insert":
                    try {
                    	 insertProduct(request, response);
                    }
                    catch(SQLException e) {
                    	e.printStackTrace();
                    }
                    break;
                case "/delete":
                	try {
                    deleteProduct(request, response);
                	}
                	 catch(SQLException | ClassNotFoundException | IOException e) {
                     	e.printStackTrace();
                     }
                    break;
                case "/edit":
                	try {                		
                		showEditForm(request, response);
                	}
                	catch(SQLException e) {
                     	e.printStackTrace();
                     }
                    break;
                case "/update":
                	try {
                    updateProduct(request, response);
                	}
                	catch(SQLException | ClassNotFoundException | IOException e) {
                     	e.printStackTrace();
                     }
                    break;
                default:
				try {
					productManagement(request, response);
				} catch (SQLException | IOException | ServletException e) {
					e.printStackTrace();
				}
                    break;
            }
        }
	
	
		private void productManagement(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, IOException,ServletException {
				ArrayList < ProductAdd > showProduct = dbController.getAllProductInfo();
			        request.setAttribute("listUser", showProduct);
			        RequestDispatcher dispatcher = request.getRequestDispatcher("product-form.jsp");
			        dispatcher.forward(request, response);
			    }
		
		//method to redirect to productadd form
		private void productAddForm(HttpServletRequest request, HttpServletResponse response)
			    throws ServletException, IOException {
			        RequestDispatcher dispatcher = request.getRequestDispatcher("product-form.jsp");
			        dispatcher.forward(request, response);		    
		}

		//method to insertProduct in database
		private void insertProduct(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, IOException {
			String productName = request.getParameter("productName");
			String productPrice = request.getParameter("productPrice");
			String productStock = request.getParameter("productStock");
			String productCategory = request.getParameter("productCategory");
			String productDescription = request.getParameter("productDescription");
      
			ProductAdd product = new ProductAdd(productName, productPrice, productStock, productCategory, productDescription);
			dbController.addProduct(product);
			response.sendRedirect("productmanagement.jsp");
			}
		
		//method to get form to update existing product in database
		private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, ServletException, IOException {
			        String productID = request.getParameter("productID");
			        ProductAdd existingProduct = dbController.selectProduct(productID);
			        RequestDispatcher dispatcher = request.getRequestDispatcher("product-form.jsp");
			        request.setAttribute("product", existingProduct);
			        dispatcher.forward(request, response);

			    }
		
		//method to update product after getting the form
		 private void updateProduct(HttpServletRequest request, HttpServletResponse response)
				    throws SQLException, IOException, ClassNotFoundException {
			 			int productID = Integer.parseInt(request.getParameter("productID"));				        
			 			String productName = request.getParameter("productName");
				        String productPrice = request.getParameter("productPrice");
				        String productStock = request.getParameter("productStock");
				        String productCategory = request.getParameter("productCategory");
				        String productDescription = request.getParameter("productDescription");

				        ProductAdd productInfo = new ProductAdd(productID,productName,productPrice,productStock,productCategory,productDescription);
				        dbController.updateUser(productInfo);
				        response.sendRedirect("productmanagement.jsp");
				    }
		
		//method to delete product from database
		private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, IOException, ClassNotFoundException {
			        String productID = request.getParameter("productID");
			        dbController.deleteProduct(productID);
			        response.sendRedirect("productmanagemet.jsp");

			    }
	
	//Put method to update existing value of database
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {    
    	
	}
}
