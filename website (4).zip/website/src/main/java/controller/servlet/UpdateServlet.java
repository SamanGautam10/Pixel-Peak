package controller.servlet;
import util.StringUtils;
import controller.DatabaseController;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class UpdateProduct
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/UpdateProduct" })
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private DatabaseController dbController;
	
    public UpdateServlet() {
    	this.dbController = new DatabaseController();
    }

    public void init() {
        // Initialize DataSource
        // dataSource = ...
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String productName = request.getParameter("productName");
        String productPrice = request.getParameter("productPrice");
        String productStock = request.getParameter("productStock");
        String productCategory = request.getParameter("productCategory");
        String productDescription = request.getParameter("productDescription");

        try (Connection connection = dbController.getConnection();
             PreparedStatement statement = connection.prepareStatement(StringUtils.UPDATE_PRODUCT)) {
            statement.setString(1, productName);
            statement.setString(2, productPrice);
            statement.setString(3, productStock);
            statement.setString(4, productCategory);
            statement.setString(5, productDescription);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                // Product updated successfully
                response.sendRedirect("productmanagement.jsp");
            } else {
            	response.sendRedirect("productmanagement.jsp");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } 
    }

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("put triggered");
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("delete triggered");
		if (dbController.deleteProductInfo(req.getParameter(StringUtils.DELETE_ID)) == 1) {
			req.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtils.URL_INDEX);
		} else {
			req.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtils.URL_INDEX);
		}
	}

}
