package controller.servlet;

import model.ProductAdd;
import util.StringUtils;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;

/**
 * Servlet implementation class UpdateProduct
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/UpdateProduct" })
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	DatabaseController dbController = new DatabaseController();
 
    public UpdateProduct() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public Connection getConnection() throws SQLException, ClassNotFoundException{
		Class.forName(StringUtils.DRIVER);
		
		return DriverManager.getConnection(StringUtils.LOCALHOST_URL, StringUtils.LOCALHOST_USER, StringUtils.LOCALHOST_PASSWORD);
	}
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPut(request,response);
	}
    
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve parameters from the request
        int productID = Integer.parseInt(request.getParameter("productID")); // Retrieve productID from hidden field
        String productName = request.getParameter("productName");
        int productPrice = Integer.parseInt(request.getParameter("productPrice"));
        int productStock = Integer.parseInt(request.getParameter("productStock"));
        String productCategory = request.getParameter("productCategory");
        String productDescription = request.getParameter("productDescription");

        // Create a Product object
        ProductAdd product = new ProductAdd();
        product.setProductID(productID); // Set productID obtained from hidden field
        product.setProductName(productName);
        product.setProductPrice(productPrice);
        product.setProductStock(productStock);
        product.setProductCategory(productCategory);
        product.setProductDescription(productDescription);

        // Update the product in the database
        try {
            DatabaseController dbController = new DatabaseController();
            boolean success = dbController.updateProduct(product);
            if (success) {
                // Product updated successfully, return success status
                response.setStatus(HttpServletResponse.SC_OK);
            } else {
                // Failed to update product, return error status
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exception, return error status
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
