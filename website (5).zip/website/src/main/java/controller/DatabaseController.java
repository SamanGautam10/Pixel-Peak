package controller;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.ProductAdd;
import util.StringUtils;

public class DatabaseController {
	//connecting to pixelpeak database
	public Connection getConnection() throws SQLException, ClassNotFoundException{
		Class.forName(StringUtils.DRIVER);
		
		return DriverManager.getConnection(StringUtils.LOCALHOST_URL, StringUtils.LOCALHOST_USER, StringUtils.LOCALHOST_PASSWORD);
	}
	
	/**
	 *This method is used to get values of the form 
	 *First we pull the value from the respective form and set it to the database
	 *result = st.executeUpdate() this line is used to set change data in database
	 */
	
	
	public int addProduct(ProductAdd product) {
		
		//getting values and inserting in database
		try (Connection con = getConnection()){
			PreparedStatement st = con.prepareStatement(StringUtils.INSERT_PRODUCT);
			
			//settings values in product table
			st.setString(1, product.getProductName());
			st.setString(2, product.getProductPrice());
			st.setString(3, product.getProductStock());
			st.setString(4, product.getProductCategory());
			st.setString(5, product.getProductDescription());
			
			//committing in database
			int result = st.executeUpdate();
			
			//returning value of result
			if (result > 0) {
	            return 1; 
	        } 
			else {
	            return 0; 
	        }
		}
		
		//error handling
		catch(SQLException | ClassNotFoundException ex){
			ex.printStackTrace(); //log the exception for debugging
			return -1;
		}
	}
	
	/**
	 * This function is used to get all the information form the database
	 * Using setter method which is in ProductAdd, we set the value of respective field
	 * 
	 */
	public ArrayList<ProductAdd> getAllProductInfo(){
		try {
			PreparedStatement st = getConnection().prepareStatement(StringUtils.GET_PRODUCT_DETAILS);
			ResultSet rs = st.executeQuery();
			
			ArrayList<ProductAdd> products = new ArrayList<ProductAdd>();
			
			while(rs.next()) {
				ProductAdd product = new ProductAdd(null, null, null, null, null);
				
				product.setProductName(rs.getString("productName"));
				product.setProductPrice(rs.getString("productPrice"));
				product.setProductStock(rs.getString("productStock"));
				product.setProductCategory(rs.getString("productCategory"));
				product.setProductDescription(rs.getString("productDescription"));
				
				products.add(product);
			}
			
			return products;
		} 
		catch(SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public int deleteProductInfo(int productID) {
	    try (Connection con = getConnection()) {
	        PreparedStatement st = con.prepareStatement(StringUtils.DELETE_PRODUCT_SQL);
	        st.setInt(1, productID);
	        return st.executeUpdate();
	    } catch (SQLException | ClassNotFoundException ex) {
	        ex.printStackTrace(); // Log the exception for debugging
	        return -1;
	    }
	}
}
