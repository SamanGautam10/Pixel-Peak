package controller.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;
import model.ProductAdd;

/**
 * Servlet implementation class ProductAddServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ProductAddServlet" })
public class ProductAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	DatabaseController dbController = new DatabaseController();
	
    public ProductAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		try {
		String productName = request.getParameter("productName");
		int productPrice = Integer.parseInt(request.getParameter("productPrice"));
		int productStock = Integer.parseInt(request.getParameter("productStock"));
		String productCategory = request.getParameter("productCategory");
		String productDescription = request.getParameter("productDescription");
		
		ProductAdd productAdd = new ProductAdd(productName, productPrice, productStock, productCategory, productDescription);
		
		int result = dbController.addStudent(productAdd);
		
		if(result > 0) {
			response.sendRedirect(request.getContextPath() + "/pages/productmanagement.jsp");
		}
		else {
			PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h3>Error: Milya xaina</h3>");
	        out.println("</body></html>");
		}
	}
		catch(Exception ex) {
			ex.printStackTrace(); //Log for exception for debugging
		}
	}
}
