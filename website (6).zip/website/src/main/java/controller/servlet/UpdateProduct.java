package controller.servlet;

import model.ProductAdd;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;

/**
 * Servlet implementation class UpdateProduct
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/UpdateProduct" })
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPut(request, response);
	}

	
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productName = request.getParameter("productName");
        int productPrice = Integer.parseInt(request.getParameter("productPrice"));
        int productStock = Integer.parseInt(request.getParameter("productStock"));
        String productCategory = request.getParameter("productCategory");
        String productDescription = request.getParameter("productDescription");
 
        // Create a ProductAdd object with updated values
        ProductAdd updatedProduct = new ProductAdd(productName, productPrice, productStock, productCategory, productDescription);
        
        // Update the product in the database
        DatabaseController dbController = new DatabaseController();
        int result = dbController.updateProduct(updatedProduct);

        // Redirect back to product management page
        if (result > 0) {
            response.sendRedirect(request.getContextPath() + "/pages/productmanagement.jsp");
        } else {
            // Handle update failure
            response.getWriter().println("Failed to update product.");
        }
	}
}
